"""Dispatcher for the simulation"""

from typing import Optional, List
from driver import Driver
from rider import Rider, WAITING, CANCELLED


class Dispatcher:
    """A dispatcher fulfills requests from riders and drivers for a
    ride-sharing service.

    When a rider requests a driver, the dispatcher assigns a driver to the
    rider. If no driver is available, the rider is placed on a waiting
    list for the next available driver. A rider that has not yet been
    picked up by a driver may cancel their request.

    When a driver requests a rider, the dispatcher assigns a rider from
    the waiting list to the driver. If there is no rider on the waiting list
    the dispatcher does nothing. Once a driver requests a rider, the driver
    is registered with the dispatcher, and will be used to fulfill future
    rider requests.

    === Private Attributes ===
    _drivers: drivers that are idle
    _waiting_list: waiting list for riders who are waiting for a driver

    === Sample Usage ===

    >>> dis = Dispatcher()
    >>> len(dis._drivers)
    0
    >>> len(dis._waiting_list)
    0
    >>> L1 = Location(2, 2)
    >>> L2 = Location(10, 1)
    >>> R = Rider('Sarah', 10, L1, L2)
    >>> dis.request_driver(R)
    None
    >>> dis._waiting_list
    [R]
    >>> L3 = Location(3, 4)
    >>> d = Driver('Bob', L1, 5)
    >>> dis._drivers
    [d]
    """
    _drivers: list
    _waiting_list: List[Rider]

    def __init__(self) -> None:
        """Initialize a Dispatcher.

        >>> dis = Dispatcher()
        >>> len(dis._drivers)
        0
        >>> len(dis._waiting_list)
        0
        >>> L1 = Location(2, 2)
        >>> L2 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L1, L2)
        >>> dis.request_driver(R)
        None
        >>> len(dis._waiting_list)
        1
        >>> L3 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> dis.request_rider(d)
        >>> len(dis._drivers)
        1
        """
        self._drivers = []
        self._waiting_list = []

    def __str__(self) -> str:
        """Return a string representation.

        >>> dis = Dispatcher()
        >>> dis.__str__()
        'Drivers: {}, Waiting List: {}'
        """

        return 'Drivers: {}, Waiting List: {}'.format(
            self._drivers, self._waiting_list)

    def request_driver(self, rider: Rider) -> Optional[Driver]:
        """Return a driver for the rider, or None if no driver is available.

        Add the rider to the waiting list if there is no available driver.

        Precondition: rider is in the waiting list

        >>> dis = Dispatcher()
        >>> L1 = Location(3, 4)
        >>> d1 = Driver('Bob', L1, 5)
        >>> dis.request_rider(d)
        None
        >>> L2 = Location(2, 2)
        >>> L3 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L1, L2)
        >>> dis.request_driver(R)
        d
        """

        number_available = 0
        for driver in self._drivers:
            if driver.is_idle:
                number_available += 1

        if number_available < 1:
            self._waiting_list.append(rider)
            rider.status = WAITING
            return None

        # if there is a driver available
        d = self._drivers[0]
        fastest = d.get_travel_time(rider.origin)
        for driver in self._drivers:
            if driver.is_idle:
                # check to see if that driver is idle
                time = driver.get_travel_time(rider.origin)
                if time <= fastest:
                    d = driver
                    fastest = time
        return d

    def request_rider(self, driver: Driver) -> Optional[Rider]:
        """Return a rider for the driver, or None if no rider is available.

        If this is a new driver, register the driver for future rider requests.

        >>> dis = Dispatcher()
        >>> L1 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> dis.request_rider(d)
        None
        >>> dis._drivers
        [d]
        """

        if driver not in self._drivers:
            self._drivers.append(driver)

        if len(self._waiting_list) > 0:
            driver.rider = self._waiting_list[0]
        else:
            return None

        return driver.rider

    def cancel_ride(self, rider: Rider) -> None:
        """Cancel the ride for rider.

        >>> dis = Dispatcher()
        >>> L1 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> dis.request_rider(d)
        None
        >>> L1 = Location(2, 2)
        >>> L2 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L1, L2)
        >>> dis.request_driver(R)
        d
        >>> dis.cancel_ride(R)
        >>> dis._waiting_list
        []
        """

        if rider in self._waiting_list:
            self._waiting_list.remove(rider)
        rider.status = CANCELLED
        rider.destination = None


if __name__ == '__main__':
    import python_ta
    python_ta.check_all(config={'extra-imports': ['typing', 'driver', 'rider']})
