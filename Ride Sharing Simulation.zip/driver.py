"""Drivers for the simulation"""

from location import Location, manhattan_distance
from rider import Rider, SATISFIED


class Driver:
    """A driver for a ride-sharing service.

    === Attributes ===
    id: A unique identifier for the driver.
    location: The current location of the driver.
    is_idle: True if the driver is idle and False otherwise.
    speed: Constant speed of the driver.
    rider: The rider if assigned and None otherwise.
    destination: the destination of the rider

    === Sample Usage ===
    >>> L1 = Location(3, 4)
    >>> d = Driver('Bob', L1, 5)
    >>> d.id
    'Bob'
    >>> d.speed
    5
    """
    # Attributes
    id: str
    location: Location
    is_idle: bool
    speed: int
    rider: Rider
    destination: Location

    def __init__(self, identifier: str, location: Location, speed: int) -> None:
        """Initialize a Driver.

        >>> L1 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> d.id
        'Bob'
        >>> d.speed
        5
        >>> d.is_idle
        True
        """

        self.id = identifier
        self.location = location
        self.speed = speed
        self.is_idle = True
        self.rider = None
        self.destination = None

    def __str__(self) -> str:
        """Return a string representation.

        >>> L1 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> d.__str__()
        'Bob - (3, 4) - 5'
        """

        return '{} - {} - {}'.format(
            self.id, self.location.__str__(), self.speed)

    def __eq__(self, other: object) -> bool:
        """Return True if self equals other, and false otherwise.

        >>> L1 = Location(3, 4)
        >>> d = Driver('Bob', L1, 5)
        >>> d1 = Driver('John', L1, 6)
        >>> d1.__eq__(d)
        True
        >>> L2 = Location(4, 4)
        >>> d2 = Driver('May', L2, 6)
        >>> d2.__eq__(d1)
        False
        """

        return self.id == other.id

    def get_travel_time(self, destination: Location) -> int:
        """Return the time it will take to arrive at the destination,
        rounded to the nearest integer.

        >>> L1 = Location(2, 1)
        >>> d = Driver('Bob', L1, 5)
        >>> L2 = Location(4, 5)
        >>> d.get_travel_time(L2)
        1
        >>> L3 = Location(3, 6)
        >>> d = Driver('John', L3, 5)
        >>> L4 = Location(9, 10)
        >>> d.get_travel_time(L4)
        2
        """

        distance = manhattan_distance(self.location, destination)  # get dist.
        return round(distance / self.speed)

    def start_drive(self, location: Location) -> int:
        """Start driving to the location.
        Return the time that the drive will take.

        >>> L1 = Location(2, 1)
        >>> d = Driver('Bob', L1, 5)
        >>> L2 = Location(4, 5)
        >>> d.start_drive(L2)
        # ?
        >>> d.is_idle
        False
        >>> d.location.__str__()
        '(4, 5)'
        """

        self.destination = location  # set destination to location
        self.is_idle = False  # change idle
        return self.get_travel_time(location)  # return time

    def end_drive(self) -> None:
        """End the drive and arrive at the destination.

        Precondition: self.destination is not None.

        >>> L1 = Location(2, 1)
        >>> d = Driver('Bob', L1, 5)
        >>> L2 = Location(4, 5)
        >>> d.start_drive(L2)
        >>> d.end_drive()
        >>> d.is_idle
        True
        >>> d.location.__str__()
        '(4, 5)'
        """

        self.location = self.destination
        self.is_idle = True
        self.destination = None

    def start_ride(self, rider: Rider) -> int:
        """Start a ride and return the time the ride will take.

        >>> L1 = Location(2, 1)
        >>> d = Driver('Bob', L1, 5)
        >>> L2 = Location(2, 2)
        >>> L3 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L2, L3)
        >>> d.start_ride(R)
        1
        """

        self.rider = rider
        self.destination = rider.destination
        self.is_idle = False
        return self.get_travel_time(self.destination)

    def end_ride(self) -> None:
        """End the current ride, and arrive at the rider's destination.

        Precondition: The driver has a rider.
        Precondition: self.destination is not None.

        >>> L1 = Location(2, 1)
        >>> d = Driver('Bob', L1, 5)
        >>> L2 = Location(2, 2)
        >>> L3 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L2, L3)
        >>> d.start_ride(R)
        1
        >>> d.end_ride()
        >>> d.rider
        None
        """

        self.rider.status = SATISFIED
        self.location = self.rider.destination
        self.rider = None  # no rider
        self.is_idle = True
        self.destination = None  # no destination


if __name__ == '__main__':
    import python_ta
    python_ta.check_all(
        config={'extra-imports': ['location', 'rider']})
