"""Locations for the simulation"""

from __future__ import annotations


class Location:
    """A two-dimensional location.

    === Attributes ===
    row: the horizontal (x) location
    column: the vertical (y) location

    === Sample Usage ===
    >>> L1 = Location(2, 1)
    >>> L2 = Location(4, 5)
    >>> L1.row
    2
    >>> L2.column
    5
    """
    # Attributes
    row: int
    column: int
    coord: tuple

    def __init__(self, row: int, column: int) -> None:
        """Initialize a location.

        Precondition: row >= 0, column >= 0

        >>> L1 = Location(2, 1)
        >>> L2 = Location(4, 5)
        >>> L1.row
        2
        >>> L2.column
        5
        """

        self.row = row
        self.column = column
        self.coord = (self.row, self.column)

    def __str__(self) -> str:
        """Return a string representation.

        >>> L1 = Location(2, 1)
        >>> L1.__str__()
        '(2, 1)'
        >>> L2 = Location(4, 5)
        >>> L2.__str__()
        '(4, 5)'
        """
        return '({}, {})'.format(self.row, self.column)

    def __eq__(self, other: Location) -> bool:
        """Return True if self equals other, and false otherwise.

        >>> L1 = Location(2, 1)
        >>> L2 = Location(4, 5)
        >>> L1.__eq__(L2)
        False
        >>> L5 = Location(2, 1)
        >>> L5.__eq__(L1)
        True
        """
        return self.row == other.row and self.column == other.column


def manhattan_distance(origin: Location, destination: Location) -> int:
    """Return the Manhattan distance between the origin and the destination.

    >>> L1 = Location(2, 1)
    >>> L2 = Location(4, 5)
    >>> manhattan_distance(L1, L2)
    6
    >>> L3 = Location(3, 6)
    >>> L4 = Location(9, 10)
    >>> manhattan_distance(L3, L4)
    10
    """
    x1 = origin.row
    x2 = destination.row

    y1 = origin.column
    y2 = destination.column

    row_total = abs(x1 - x2)
    column_total = abs(y1 - y2)

    return row_total + column_total


def deserialize_location(location_str: str) -> Location:
    """Deserialize a location.

    location_str: A location in the format 'row,col'

    >>> l = '3,4'
    >>> l_new = deserialize_location(l)
    >>> l_new.row
    3
    >>> l_new.column
    4
    """

    location = location_str.split(',')
    row = int(location[0])
    column = int(location[1])

    return Location(row, column)


if __name__ == '__main__':
    import python_ta
    python_ta.check_all()
