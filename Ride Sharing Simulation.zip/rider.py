"""
The rider module contains the Rider class. It also contains
constants that represent the status of the rider.

=== Constants ===
WAITING: A constant used for the waiting rider status.
CANCELLED: A constant used for the cancelled rider status.
SATISFIED: A constant used for the satisfied rider status
"""

from location import Location

WAITING = "waiting"
CANCELLED = "cancelled"
SATISFIED = "satisfied"


class Rider:

    """A rider for a ride-sharing service.

    === Attributes ===
    identifier: the riders identity
    patience: the patience of the rider
    origin: origin of the rider
    destination: destination of the rider
    status: status of the rider

    === Sample Usage ===
    Creating a rider
    >>> L1 = Location(2, 2)
    >>> L2 = Location(10, 1)
    >>> r = Rider('Sarah', 10, L1, L2)
    >>> r.id
    'Sarah'
    >>> r.patience
    10
    """
    # Attributes
    id: str
    patience: int
    origin: Location
    destination: Location
    status: str

    def __init__(self, identifier: str, patience: int, origin: Location,
                 destination: Location) -> None:
        """Initialize a Rider.

        >>> L1 = Location(2, 2)
        >>> L2 = Location(10, 1)
        >>> r = Rider('Sarah', 10, L1, L2)
        >>> r.id
        'Sarah'
        >>> r.patience
        10
        """
        self.id = identifier
        self.patience = patience
        self.origin = origin
        self.destination = destination
        self.status = WAITING

    def __str__(self) -> str:
        """Return a string representation.

        >>> L1 = Location(2, 2)
        >>> L2 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L1, L2)
        >>> R.__str__()
        'waiting - 10 - (2, 2) - (10, 1)'
        """

        s = "{} - {} - {} - {}".format(
            self.status, self.patience, self.origin.__str__(),
            self.destination.__str__())
        return s

    def __eq__(self, other: object) -> bool:
        """Return True if self equals other, and False otherwise.

        >>> L1 = Location(2, 2)
        >>> L2 = Location(10, 1)
        >>> R = Rider('Sarah', 10, L1, L2)
        >>> L3 = Location(3, 1)
        >>> L4 = Location(2, 2)
        >>> R1 = Rider('Bob', 10, L3, L4)
        >>> R.__eq__(R1)
        True
        >>> R2 = Rider('May', 1, L3, L4)
        >>> R1.__eq__(R2)
        False
        """

        return self.patience == other.patience


if __name__ == '__main__':
    import python_ta
    python_ta.check_all(config={'extra-imports': ['location']})
